select Major, count(*) as 'Total_Number_of_Students'
from students
group by Major